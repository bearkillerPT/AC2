#include <detpic32.h>
#include "i2c.h"
#include "eeprom.h"
void delay(unsigned int ms);

int getTemperature(int *temperature) {
    int ack;
    i2c1_start();
    ack = i2c1_send(ADDR_WR);
    ack += i2c1_send(RTR);
    i2c1_start();
    ack += i2c1_send(ADDR_RD);
    if(ack != 0) {
        i2c1_stop();
        printStr("Ack error exiting...");
        return 1;
    }
    *temperature = i2c1_receive(I2C_NACK);
    i2c1_stop();
// Send Stop event
    return ack;
}

int main(void) {
    spi2_setClock(EEPROM_CLOCK);
    spi2_init();
    int addr = 0x02;
    int samples = 0;
    char key;
    int temp = 0;
    i2c1_init(TC74_CLK_FREQ);
    while(1) {
        key = getChar();
        switch (key)
        {
        case "R" || "r":
            eeprom_writeData(0, 0);
            break;
        case "L" || "l":
            for(samples = 0; samples < 64, samples++) {
                key = inkey();
                if(key == "R" || key == "r" || key == "S" || key == "s") break;
                getTemperature(&temp);
                eeprom_writeData(0, (char) samples);
                eeprom_writeData(addr, (char) temp);
                addr++;
                delay(15000);
            }
            break;
        case "S" || "s":
            samples = eeprom_readData(0);
            printStr("Numero de amostras: " + samples + "\n");
            int i;
            for(i = 0; i < samples; i++) {
                if(i % 4 == 0) printStr("Sample minuto: " + i/4 + ":\n");
                printStr("  " + eeprom_readData(0x02 + i) + ", \n");
            }
            break;
        default:
            break;
        }
    }
} 

void delay(unsigned int ms) {
  int k = PBCLK / 1000;
  for (; ms > 0; ms--) {
    resetCoreTimer();
    while (readCoreTimer() < k)
      ;
  }
}
